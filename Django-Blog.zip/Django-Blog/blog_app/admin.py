from django.contrib import admin
from .models import BlogPost
from django.contrib.auth.models import Group
from django.utils.html import format_html

admin.site.site_header = "Harsh's Blogging Application"
admin.site.site_title = "Harsh's Blogging App"


# Register your models here.
#admin.site.register(BlogPost)

admin.site.unregister(Group)

class CustomAdminPost(admin.ModelAdmin):
    list_display = ('title','publish_date','Blog_Content')
    date_hierarchy = 'publish_date'
    empty_value_display = 'NA'
    list_filter = ('author','publish_date')
    search_fields = ('author__username','title','publish_date')
    list_per_page = 4
    list_display_links = ('Blog_Content',)
    list_editable = ('title','publish_date')

    def Blog_Content(self,obj):
        return format_html(f'<span style="color:red;"><strong>{obj.blog_content[:31]}</strong></span>')
    


admin.site.register(BlogPost,CustomAdminPost)


