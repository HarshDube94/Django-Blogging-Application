from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponse
from .models import BlogPost
from .forms import PostBlogForm,RegistrationForm
from django.utils import timezone
from django.contrib import messages
from django.urls import reverse_lazy
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
# Create your views here.
def blog_list(request):
    mydata = BlogPost.objects.all().order_by('-publish_date')
    return render(request,'blog_app/post-list.html',{'post_info':mydata})
    #all_data = BlogPost.objects.all()
    #return HttpResponse(all_data)
@login_required(login_url='login')
def post_detail(request,pk):
    # print('Id is:',pk)
    post_data = get_object_or_404(BlogPost,pk=pk)
    print('Post data is',post_data)
    return render(request,'blog_app/post_detail.html',
    {'post':post_data})

def post_new(request):
    if request.method == 'POST':
        form_data = PostBlogForm(request.POST)
        if form_data.is_valid():
            post_data = form_data.save(commit=False)
            post_data.author = request.user
            post_data.create_date = timezone.now()
            post_data.save()
            messages.success(request,'Data has been inserted successfully')
            return redirect('blog_list')
    else:
       form_data = PostBlogForm()
    return render(request,'blog_app/post_new_edit.html',{'form_data':form_data})

def post_edit(request,pk):
    post_data = get_object_or_404(BlogPost,pk=pk)
    if request.method == "POST":
        form_data = PostBlogForm(request.POST,instance=post_data)
        if form_data.is_valid():
            post_data = form_data.save(commit=False)
            post_data.author = request.user
            post_data.create_date = timezone.now()
            post_data.save()
            messages.success(request,'Data Updated Successfully')
            return redirect('blog_list')
    else:
        form_data = PostBlogForm(instance=post_data)
    return render(request,'blog_app/post_new_edit.html',{'form_data':form_data})


def post_delete(request,pk):
    post = get_object_or_404(BlogPost,pk=pk)
    post.delete()
    messages.info(request,'Data has been deleted successfully')
    return redirect('blog_list')

def register(request):
    if request.method == "GET":
        form = RegistrationForm()
        #context = {'form':form}
        return render(request,'register.html',{'form':form})

    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            user_name = form.cleaned_data.get('username')
            messages.success(request,'Account was created for '+user_name)
            return redirect('blog_list')

        else:
            messages.error(request,'Error processing your request')
            return render(request,'register.html',{'form':form})

    return render(request,'register.html',{'form':form})




    
    

